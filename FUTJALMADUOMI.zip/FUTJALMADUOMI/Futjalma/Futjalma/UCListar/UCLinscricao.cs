﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma.UCListar
{
    public partial class UCLinscricao : UserControl
    {
        public UCLinscricao()
        {
            InitializeComponent();
        }

        private void UCLinscricao_Load(object sender, EventArgs e)
        {
            FutjalmaEntities entities = new FutjalmaEntities();
            dataGridView1.DataSource = entities.Inscricao.ToArray();
            dataGridView1.ReadOnly = true;

        }
    }
}
