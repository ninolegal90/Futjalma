﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma.UCListar
{
    public partial class UCLclube : UserControl
    {
        public UCLclube()
        {
            InitializeComponent();
        }

        private void UCLclube_Load(object sender, EventArgs e)
        {
            FutjalmaEntities entities = new FutjalmaEntities();
            dataGridView1.DataSource = entities.Clube.ToArray();
            dataGridView1.ReadOnly = true;

        }
    }
}
