﻿namespace Futjalma
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gerenciarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jOGADORESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNSCRIÇÕESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cAMPEONATOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.cONTRATOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.cLUBESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.jOGOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gerenciarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(835, 31);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gerenciarToolStripMenuItem
            // 
            this.gerenciarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jOGADORESToolStripMenuItem,
            this.iNSCRIÇÕESToolStripMenuItem,
            this.cAMPEONATOSToolStripMenuItem,
            this.cONTRATOSToolStripMenuItem,
            this.cLUBESToolStripMenuItem,
            this.jOGOSToolStripMenuItem});
            this.gerenciarToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gerenciarToolStripMenuItem.Name = "gerenciarToolStripMenuItem";
            this.gerenciarToolStripMenuItem.Size = new System.Drawing.Size(113, 27);
            this.gerenciarToolStripMenuItem.Text = "Gerenciar";
            // 
            // jOGADORESToolStripMenuItem
            // 
            this.jOGADORESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem,
            this.adicionarToolStripMenuItem,
            this.atualizarToolStripMenuItem,
            this.excluirToolStripMenuItem});
            this.jOGADORESToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jOGADORESToolStripMenuItem.Name = "jOGADORESToolStripMenuItem";
            this.jOGADORESToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.jOGADORESToolStripMenuItem.Text = "JOGADORES";
            this.jOGADORESToolStripMenuItem.Click += new System.EventHandler(this.jOGADORESToolStripMenuItem_Click);
            // 
            // listarToolStripMenuItem
            // 
            this.listarToolStripMenuItem.Name = "listarToolStripMenuItem";
            this.listarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listarToolStripMenuItem.Text = "Listar";
            this.listarToolStripMenuItem.Click += new System.EventHandler(this.listarToolStripMenuItem_Click);
            // 
            // adicionarToolStripMenuItem
            // 
            this.adicionarToolStripMenuItem.Name = "adicionarToolStripMenuItem";
            this.adicionarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.adicionarToolStripMenuItem.Text = "Adicionar";
            this.adicionarToolStripMenuItem.Click += new System.EventHandler(this.adicionarToolStripMenuItem_Click);
            // 
            // atualizarToolStripMenuItem
            // 
            this.atualizarToolStripMenuItem.Name = "atualizarToolStripMenuItem";
            this.atualizarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.atualizarToolStripMenuItem.Text = "Atualizar";
            this.atualizarToolStripMenuItem.Click += new System.EventHandler(this.atualizarToolStripMenuItem_Click);
            // 
            // excluirToolStripMenuItem
            // 
            this.excluirToolStripMenuItem.Name = "excluirToolStripMenuItem";
            this.excluirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.excluirToolStripMenuItem.Text = "Excluir";
            // 
            // iNSCRIÇÕESToolStripMenuItem
            // 
            this.iNSCRIÇÕESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem1,
            this.adicionarToolStripMenuItem1,
            this.atualizarToolStripMenuItem1,
            this.excluirToolStripMenuItem1});
            this.iNSCRIÇÕESToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iNSCRIÇÕESToolStripMenuItem.Name = "iNSCRIÇÕESToolStripMenuItem";
            this.iNSCRIÇÕESToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.iNSCRIÇÕESToolStripMenuItem.Text = "INSCRIÇÕES";
            // 
            // listarToolStripMenuItem1
            // 
            this.listarToolStripMenuItem1.Name = "listarToolStripMenuItem1";
            this.listarToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.listarToolStripMenuItem1.Text = "Listar";
            this.listarToolStripMenuItem1.Click += new System.EventHandler(this.listarToolStripMenuItem1_Click);
            // 
            // adicionarToolStripMenuItem1
            // 
            this.adicionarToolStripMenuItem1.Name = "adicionarToolStripMenuItem1";
            this.adicionarToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.adicionarToolStripMenuItem1.Text = "Adicionar";
            this.adicionarToolStripMenuItem1.Click += new System.EventHandler(this.adicionarToolStripMenuItem1_Click);
            // 
            // atualizarToolStripMenuItem1
            // 
            this.atualizarToolStripMenuItem1.Name = "atualizarToolStripMenuItem1";
            this.atualizarToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.atualizarToolStripMenuItem1.Text = "Atualizar";
            // 
            // excluirToolStripMenuItem1
            // 
            this.excluirToolStripMenuItem1.Name = "excluirToolStripMenuItem1";
            this.excluirToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.excluirToolStripMenuItem1.Text = "Excluir";
            // 
            // cAMPEONATOSToolStripMenuItem
            // 
            this.cAMPEONATOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem2,
            this.atualizarToolStripMenuItem2,
            this.atualizarToolStripMenuItem3,
            this.excluirToolStripMenuItem2});
            this.cAMPEONATOSToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cAMPEONATOSToolStripMenuItem.Name = "cAMPEONATOSToolStripMenuItem";
            this.cAMPEONATOSToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.cAMPEONATOSToolStripMenuItem.Text = "CAMPEONATOS";
            // 
            // listarToolStripMenuItem2
            // 
            this.listarToolStripMenuItem2.Name = "listarToolStripMenuItem2";
            this.listarToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.listarToolStripMenuItem2.Text = "Listar";
            this.listarToolStripMenuItem2.Click += new System.EventHandler(this.listarToolStripMenuItem2_Click);
            // 
            // atualizarToolStripMenuItem2
            // 
            this.atualizarToolStripMenuItem2.Name = "atualizarToolStripMenuItem2";
            this.atualizarToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.atualizarToolStripMenuItem2.Text = "Adicionar";
            this.atualizarToolStripMenuItem2.Click += new System.EventHandler(this.atualizarToolStripMenuItem2_Click);
            // 
            // atualizarToolStripMenuItem3
            // 
            this.atualizarToolStripMenuItem3.Name = "atualizarToolStripMenuItem3";
            this.atualizarToolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.atualizarToolStripMenuItem3.Text = "Atualizar";
            this.atualizarToolStripMenuItem3.Click += new System.EventHandler(this.atualizarToolStripMenuItem3_Click);
            // 
            // excluirToolStripMenuItem2
            // 
            this.excluirToolStripMenuItem2.Name = "excluirToolStripMenuItem2";
            this.excluirToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.excluirToolStripMenuItem2.Text = "Excluir";
            // 
            // cONTRATOSToolStripMenuItem
            // 
            this.cONTRATOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem3,
            this.adicionarToolStripMenuItem2,
            this.atualizarToolStripMenuItem4,
            this.excluirToolStripMenuItem3});
            this.cONTRATOSToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cONTRATOSToolStripMenuItem.Name = "cONTRATOSToolStripMenuItem";
            this.cONTRATOSToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.cONTRATOSToolStripMenuItem.Text = "CONTRATOS";
            // 
            // listarToolStripMenuItem3
            // 
            this.listarToolStripMenuItem3.Name = "listarToolStripMenuItem3";
            this.listarToolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.listarToolStripMenuItem3.Text = "Listar";
            this.listarToolStripMenuItem3.Click += new System.EventHandler(this.listarToolStripMenuItem3_Click);
            // 
            // adicionarToolStripMenuItem2
            // 
            this.adicionarToolStripMenuItem2.Name = "adicionarToolStripMenuItem2";
            this.adicionarToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.adicionarToolStripMenuItem2.Text = "Adicionar";
            this.adicionarToolStripMenuItem2.Click += new System.EventHandler(this.adicionarToolStripMenuItem2_Click);
            // 
            // atualizarToolStripMenuItem4
            // 
            this.atualizarToolStripMenuItem4.Name = "atualizarToolStripMenuItem4";
            this.atualizarToolStripMenuItem4.Size = new System.Drawing.Size(152, 22);
            this.atualizarToolStripMenuItem4.Text = "Atualizar";
            // 
            // excluirToolStripMenuItem3
            // 
            this.excluirToolStripMenuItem3.Name = "excluirToolStripMenuItem3";
            this.excluirToolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.excluirToolStripMenuItem3.Text = "Excluir";
            // 
            // cLUBESToolStripMenuItem
            // 
            this.cLUBESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem4,
            this.adicionarToolStripMenuItem3,
            this.atualizarToolStripMenuItem5,
            this.excluirToolStripMenuItem4});
            this.cLUBESToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cLUBESToolStripMenuItem.Name = "cLUBESToolStripMenuItem";
            this.cLUBESToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.cLUBESToolStripMenuItem.Text = "CLUBES";
            this.cLUBESToolStripMenuItem.Click += new System.EventHandler(this.cLUBESToolStripMenuItem_Click);
            // 
            // listarToolStripMenuItem4
            // 
            this.listarToolStripMenuItem4.Name = "listarToolStripMenuItem4";
            this.listarToolStripMenuItem4.Size = new System.Drawing.Size(152, 22);
            this.listarToolStripMenuItem4.Text = "Listar";
            this.listarToolStripMenuItem4.Click += new System.EventHandler(this.listarToolStripMenuItem4_Click);
            // 
            // adicionarToolStripMenuItem3
            // 
            this.adicionarToolStripMenuItem3.Name = "adicionarToolStripMenuItem3";
            this.adicionarToolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.adicionarToolStripMenuItem3.Text = "Adicionar";
            this.adicionarToolStripMenuItem3.Click += new System.EventHandler(this.adicionarToolStripMenuItem3_Click);
            // 
            // atualizarToolStripMenuItem5
            // 
            this.atualizarToolStripMenuItem5.Name = "atualizarToolStripMenuItem5";
            this.atualizarToolStripMenuItem5.Size = new System.Drawing.Size(152, 22);
            this.atualizarToolStripMenuItem5.Text = "Atualizar";
            // 
            // excluirToolStripMenuItem4
            // 
            this.excluirToolStripMenuItem4.Name = "excluirToolStripMenuItem4";
            this.excluirToolStripMenuItem4.Size = new System.Drawing.Size(152, 22);
            this.excluirToolStripMenuItem4.Text = "Excluir";
            // 
            // jOGOSToolStripMenuItem
            // 
            this.jOGOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem5,
            this.adicionarToolStripMenuItem4,
            this.atualizarToolStripMenuItem6,
            this.excluirToolStripMenuItem5});
            this.jOGOSToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jOGOSToolStripMenuItem.Name = "jOGOSToolStripMenuItem";
            this.jOGOSToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.jOGOSToolStripMenuItem.Text = "JOGOS";
            // 
            // listarToolStripMenuItem5
            // 
            this.listarToolStripMenuItem5.Name = "listarToolStripMenuItem5";
            this.listarToolStripMenuItem5.Size = new System.Drawing.Size(152, 22);
            this.listarToolStripMenuItem5.Text = "Listar";
            this.listarToolStripMenuItem5.Click += new System.EventHandler(this.listarToolStripMenuItem5_Click);
            // 
            // adicionarToolStripMenuItem4
            // 
            this.adicionarToolStripMenuItem4.Name = "adicionarToolStripMenuItem4";
            this.adicionarToolStripMenuItem4.Size = new System.Drawing.Size(152, 22);
            this.adicionarToolStripMenuItem4.Text = "Adicionar";
            this.adicionarToolStripMenuItem4.Click += new System.EventHandler(this.adicionarToolStripMenuItem4_Click);
            // 
            // atualizarToolStripMenuItem6
            // 
            this.atualizarToolStripMenuItem6.Name = "atualizarToolStripMenuItem6";
            this.atualizarToolStripMenuItem6.Size = new System.Drawing.Size(152, 22);
            this.atualizarToolStripMenuItem6.Text = "Atualizar";
            // 
            // excluirToolStripMenuItem5
            // 
            this.excluirToolStripMenuItem5.Name = "excluirToolStripMenuItem5";
            this.excluirToolStripMenuItem5.Size = new System.Drawing.Size(152, 22);
            this.excluirToolStripMenuItem5.Text = "Excluir";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 531);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(835, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(835, 500);
            this.panel1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(835, 553);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem gerenciarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jOGADORESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adicionarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNSCRIÇÕESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem adicionarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cAMPEONATOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cONTRATOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem adicionarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem cLUBESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem adicionarToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem jOGOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem adicionarToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem5;
    }
}

