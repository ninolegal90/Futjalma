﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma
{
    public partial class UCclube : UserControl
    {
        public UCclube()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FutjalmaEntities entities = new FutjalmaEntities();

                Clube clube = new Clube();

                clube.Nome = textBox1.Text;
                clube.Fundacao = dateTimePicker1.Value;

                entities.Clube.Add(clube);
                entities.SaveChanges();

                MessageBox.Show("DADOS CADASTRADOS COM SUCESSO!!!", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show("NÃO FOI POSSÍVEL CADASTRAR NENHUM DADO.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void close()
        {
            this.Parent.Controls.Remove(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }
    }
}
        
    

