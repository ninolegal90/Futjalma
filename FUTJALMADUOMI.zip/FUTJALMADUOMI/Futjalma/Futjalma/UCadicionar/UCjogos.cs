﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Futjalma
{
    public partial class UCjogos : UserControl
    {
        public UCjogos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FutjalmaEntities entities = new FutjalmaEntities();

                Partida jogos = new Partida();

                jogos.CampeonatoID = Convert.ToInt32(numericUpDown1.Value);
                jogos.Clube1ID = Convert.ToInt32(numericUpDown2.Value);
                jogos.Clube2ID = Convert.ToInt32(numericUpDown4.Value);
                jogos.Placar1 = Convert.ToInt32(numericUpDown3.Value);
                jogos.Placar2 = Convert.ToInt32(numericUpDown5.Value);

                entities.Partida.Add(jogos);
                entities.SaveChanges();

                MessageBox.Show("A quantidade jogos foi inserida com sucesso!.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show("Não foi possivel inserir a quantidade especificada.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void close()
        {
            this.Parent.Controls.Remove(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }
    }
}
        
    

