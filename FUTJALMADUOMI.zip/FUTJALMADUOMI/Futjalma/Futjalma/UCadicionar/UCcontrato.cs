﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma
{
    public partial class UCcontrato : UserControl
    {
        public UCcontrato()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FutjalmaEntities entities = new FutjalmaEntities();

                Contratacao contrato = new Contratacao();

                contrato.JogadorID = Convert.ToInt32(numericUpDown1.Value);
                contrato.ClubeID = Convert.ToInt32(numericUpDown2.Value);
                contrato.Camisa = Convert.ToInt32(numericUpDown3.Value);
                contrato.Fechamento = dateTimePicker1.Value;

                entities.Contratacao.Add(contrato);
                entities.SaveChanges();

                MessageBox.Show("Dados inseridos com sucesso.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show("Não foi possível cadastrar nenhum dado.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void close()
        {
            this.Parent.Controls.Remove(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }
    }
}
        
    

