﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Futjalma
{
    public partial class UCcampeonato : UserControl
    {
        public UCcampeonato()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FutjalmaEntities entities = new FutjalmaEntities();

                Campeonato camp = new Campeonato();

                camp.Nome = textBox1.Text;
                camp.Inicio = dateTimePicker1.Value;
                camp.Premiacao = Convert.ToInt32(numericUpDown1.Value);
                camp.Campeao = Convert.ToInt32(numericUpDown2.Value);
                entities.Campeonato.Add(camp);
                entities.SaveChanges();

                MessageBox.Show("Campeonato cadastrado com sucesso.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show("Não foi possível cadastrar o campeonato.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void close()
        {
            this.Parent.Controls.Remove(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }

        private void UCcampeonato_Load(object sender, EventArgs e)
        {

        }
    }
}



