﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma
{
    public partial class UCinscricao : UserControl
    {
        public UCinscricao()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FutjalmaEntities entities = new FutjalmaEntities();

                Inscricao inscricao = new Inscricao();

                inscricao.ClubeID = Convert.ToInt32(numericUpDown1.Value);
                inscricao.CampeonatoID = Convert.ToInt32(numericUpDown2.Value);

                entities.Inscricao.Add(inscricao);
                entities.SaveChanges();

                MessageBox.Show("INSCRIÇÃO REALIZADA COM SUCESSO.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show("ERRO AO REALIZAR A INSCRIÇÃO.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void close()
        {
            this.Parent.Controls.Remove(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }
    }
}
        
    

