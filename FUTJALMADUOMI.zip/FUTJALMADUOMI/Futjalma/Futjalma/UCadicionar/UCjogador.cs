﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma
{
    public partial class UCjogador : UserControl
    {
        private static string Nome;
        private static DateTime DataNascimento;

        public UCjogador()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FutjalmaEntities entities = new FutjalmaEntities();

                Jogador jogador = new Jogador();

                jogador.Nome = textBox1.Text;
                jogador.DataNascimento = dateTimePicker1.Value;

                entities.Jogador.Add(jogador);
                entities.SaveChanges();

                MessageBox.Show("JOGADOR INSERIDO COM SUCESSO.", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show("ERRO AO INSERIR JOGADOR", "Futjalma", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void close()
        {
            this.Parent.Controls.Remove(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }
    }
}
        
    

