﻿using Futjalma.UCAtualizar;
using Futjalma.UCListar;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void jOGADORESToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void adicionarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UCjogador UCjogador = new UCjogador();
            UCjogador.Dock = DockStyle.Fill;
            panel1.Controls.Add(UCjogador);
            UCjogador.BringToFront();
        }

        private void adicionarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            UCinscricao UCinscricao = new UCinscricao();
            UCinscricao.Dock = DockStyle.Fill;
            panel1.Controls.Add(UCinscricao);
            UCinscricao.BringToFront();
        }

        private void atualizarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            UCcampeonato uCcampeonato = new UCcampeonato();
            uCcampeonato.Dock = DockStyle.Fill;
            panel1.Controls.Add(uCcampeonato);
            uCcampeonato.BringToFront();

        }

        private void adicionarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            UCcontrato UCcontrato = new UCcontrato();
            UCcontrato.Dock = DockStyle.Fill;
            panel1.Controls.Add(UCcontrato);
            UCcontrato.BringToFront();

        }

        private void adicionarToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            UCclube UCclube = new UCclube();
            UCclube.Dock = DockStyle.Fill;
            panel1.Controls.Add(UCclube);
            UCclube.BringToFront();

        }

        private void adicionarToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            UCjogos UCjogos = new UCjogos();
            UCjogos.Dock = DockStyle.Fill;
            panel1.Controls.Add(UCjogos);
            UCjogos.BringToFront();

        }

        private void listarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UCListar.UCLjogador jogador = new UCListar.UCLjogador();
            jogador.Dock = DockStyle.Fill;
            panel1.Controls.Add(jogador);
            jogador.BringToFront();

        }

        private void listarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            UCListar.UCLinscricao inscricao = new UCListar.UCLinscricao();
            inscricao.Dock = DockStyle.Fill;
            panel1.Controls.Add(inscricao);
            inscricao.BringToFront();
        }

        private void listarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            UCListar.UCLCampeonato camp = new UCListar.UCLCampeonato();
            camp.Dock = DockStyle.Fill;
            panel1.Controls.Add(camp);
            camp.BringToFront();


        }

        private void listarToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            UCListar.UCLContrato contrato = new UCListar.UCLContrato();
            contrato.Dock = DockStyle.Fill;
            panel1.Controls.Add(contrato);
            contrato.BringToFront();

        }

        private void listarToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            UCListar.UCLclube clube = new UCListar.UCLclube();
            clube.Dock = DockStyle.Fill;
            panel1.Controls.Add(clube);
            clube.BringToFront();

        }

        private void listarToolStripMenuItem5_Click(object sender, EventArgs e)
        {
            UCListar.UCjogos jogos = new UCListar.UCjogos();
            jogos.Dock = DockStyle.Fill;
            panel1.Controls.Add(jogos);
            jogos.BringToFront();

        }

        private void cLUBESToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void atualizarToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();

            UCAcampeonato component = new UCAcampeonato();

            component.Dock = DockStyle.Fill;
            panel1.Controls.Add(component);

        }

        private void atualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();

            UCAjogador component = new UCAjogador();

            component.Dock = DockStyle.Fill;
            panel1.Controls.Add(component);
            
        }
    }
}
