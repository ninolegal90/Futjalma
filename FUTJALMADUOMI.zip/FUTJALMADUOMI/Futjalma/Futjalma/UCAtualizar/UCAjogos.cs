﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace futebol
{
    public partial class UCAjogos : UserControl
    {
        UCAjogos jogo = null;

        public UCAjogos()
        {
            InitializeComponent();

            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                tbSearch.AutoCompleteCustomSource.AddRange(
                    entities.Partida
                        .Select(p => p.ID + " - " + p.CampeonatoID)
                        .ToArray()
                    );
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                jogo = entities.Partida
                    .FirstOrDefault(
                        p => tbSearch.Text == p.ID + " - " + p.CampeonatoID);
            }

            if (jogo == null)
            {
                pnUpdate.Enabled = false;

                numericUpDown1.Value = 0;
                numericUpDown2.Value = 0;
                numericUpDown3.Value = 0;
                numericUpDown4.Value = 0;
                numericUpDown5.Value = 0;

                return;
            }

            numericUpDown1.Value = Convert.ToInt32(jogo.CampeonatoID);
            numericUpDown2.Value = jogo.Clube1ID;
            numericUpDown3.Value = jogo.Clube2ID;
            numericUpDown4.Value = jogo.Placar1;
            numericUpDown5.Value = jogo.Placar2;

            pnUpdate.Enabled = true;
        }

        private void close()
        {
            this.Parent.Controls.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (FutjalmaEntities entities = new FutjalmaEntities())
                {
                    entities.Partida.Attach(jogo);

                    jogo.CampeonatoID = Convert.ToInt32(numericUpDown1.Value);
                    jogo.Clube1ID = Convert.ToInt32(numericUpDown2.Value);
                    jogo.Clube2ID = Convert.ToInt32(numericUpDown3.Value);
                    jogo.Placar1 = Convert.ToInt32(numericUpDown4.Value);
                    jogo.Placar2 = Convert.ToInt32(numericUpDown5.Value);

                    entities.SaveChanges();
                }

                MessageBox.Show(
                    "Jogo atualizado com sucesso.",
                    "Sucesso.",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show(
                    "Não foi possível atualizar o jogo.",
                    "Erro.",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
