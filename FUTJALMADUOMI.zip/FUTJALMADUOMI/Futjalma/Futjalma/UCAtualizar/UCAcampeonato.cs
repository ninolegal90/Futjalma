﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futjalma.UCAtualizar
{
    public partial class UCAcampeonato : UserControl
    {
        Campeonato campeonato = null;
        public UCAcampeonato()
        {
            InitializeComponent();

            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                tbSearch.AutoCompleteCustomSource.AddRange(
                    entities.Campeonato
                        .Select(j => j.Nome + " - " + j.ID)
                        .ToArray()
                    );
            }
        }

        private void tbPesquisa_TextChanged(object sender, EventArgs e)
        {
            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                campeonato = entities.Campeonato
                    .FirstOrDefault(
                        j => tbSearch.Text == j.Nome + " - " + j.ID);
            }

            if (campeonato == null)
            {
                pnUpdate.Enabled = false;
                textBox1.Text = "";
                dtpStart.Value = DateTime.Now;
                nudPrem.Value = 0;
                textBox2.Text = "";

             

                return;
            }

            textBox1.Text = campeonato.Nome;
            dtpStart.Value = campeonato.Inicio;
            nudPrem.Value = campeonato.Premiacao;
            textBox2.Text = campeonato.Campeao.ToString();

          
            pnUpdate.Enabled = true;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
    

