﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace futebol
{
    public partial class UCAjogador : UserControl
    {
        UCAjogador jogador = null;

        public UCAjogador()
        {
            InitializeComponent();

            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                tbSearch.AutoCompleteCustomSource.AddRange(
                    entities.Jogador
                        .Select(j => j.Nome + " - " + j.ID)
                        .ToArray()
                    );
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                jogador = entities.Jogador
                    .FirstOrDefault(
                        j => tbSearch.Text == j.Nome + " - " + j.ID);
            }

            if (jogador == null)
            {
                pnUpdate.Enabled = false;

                tbID.Text = "";
                tbName.Text = "";
                dtpBirthdate.Value = DateTime.Now;
                photoPicker1.Photo = null;

                return;
            }

            tbName.Text = jogador.Nome;
            tbID.Text = jogador.ID.ToString();
            dtpBirthdate.Value = jogador.DataNascimento;
            photoPicker1.Photo = jogador.Foto;

            pnUpdate.Enabled = true;
        }

        private void close()
        {
            this.Parent.Controls.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (FutjalmaEntities entities = new FutjalmaEntities())
                {
                    entities.Jogador.Attach(jogador);

                    jogador.Nome = tbName.Text;
                    jogador.DataNascimento = dtpBirthdate.Value;
                    jogador.Foto = photoPicker1.Photo;

                    entities.SaveChanges();
                }

                MessageBox.Show(
                    "Jogador atualizado com sucesso.",
                    "Sucesso.",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show(
                    "Não foi possível atualizar o jogador.",
                    "Erro.",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
