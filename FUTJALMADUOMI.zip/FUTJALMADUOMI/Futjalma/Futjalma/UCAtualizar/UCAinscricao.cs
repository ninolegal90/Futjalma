﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace futebol
{
    public partial class UCAinscrição : UserControl
    {
        UCAinscrição inscricao = null;

        public UCAinscrição()
        {
            InitializeComponent();

            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                tbSearch.AutoCompleteCustomSource.AddRange(
                    entities.Inscricao
                        .Select(i => i.ID + " - " + i.ClubeID)
                        .ToArray()
                    );
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            using (FutjalmaEntities entities = new FutjalmaEntities())
            {
                inscricao = entities.Inscricao
                    .FirstOrDefault(
                        i => tbSearch.Text == i.ID + " - " + i.ClubeID);
            }

            if (inscricao == null)
            {
                pnUpdate.Enabled = false;

                numericUpDown1.Value = 0;
                numericUpDown2.Value = 0;
                numericUpDown3.Value = 0;

                return;
            }

            numericUpDown1.Value = inscricao.ID;
            numericUpDown2.Value = inscricao.ClubeID;
            numericUpDown3.Value = Convert.ToInt32(inscricao.CampeonatoID);

            pnUpdate.Enabled = true;
        }

        private void close()
        {
            this.Parent.Controls.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (FutjalmaEntities entities = new FutjalmaEntities())
                {
                    entities.Inscricao.Attach(inscricao);

                    inscricao.ClubeID = Convert.ToInt32(numericUpDown2.Value);
                    inscricao.CampeonatoID = Convert.ToInt32(numericUpDown3.Value);

                    entities.SaveChanges();
                }

                MessageBox.Show(
                    "Inscrição atualizada com sucesso.",
                    "Sucesso.",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                close();
            }
            catch
            {
                MessageBox.Show(
                    "Não foi possível atualizar a inscrição.",
                    "Erro.",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
